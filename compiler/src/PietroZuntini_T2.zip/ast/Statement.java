/**
 * Integrantes:
 * Pietro Zuntini Bonfim    RA: 743588
 */

package ast;

abstract public class Statement {

	abstract public void genC(PW pw);
	abstract public void genJava(PW pw);

}
